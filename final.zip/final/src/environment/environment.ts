export const environment = {
  production: false,
  // fbAppId: 186848361921511,
  googleWebClientId: '401245627689-ke4oci7bc8440anmpo4dms1od5keoome.apps.googleusercontent.com',
  firebase: {
    apiKey: "AIzaSyA5BPoNZo9YvagNgESYY565d0FdCxUwJcc",
    authDomain: "final-cb8b7.firebaseapp.com",
    databaseURL: "https://final-cb8b7.firebaseio.com",
    projectId: "final-cb8b7",
    storageBucket: "final-cb8b7.appspot.com",
    messagingSenderId: "862926734770"
  }
};
